const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://billingadmin:Billing%40123@fastfresh.kgpgfdt.mongodb.net/gstbilling"
    );
    console.log("✅ MongoDB Connected Successfully");
  } catch (error) {
    console.log("❌ MongoDB Connection Failed", error);
  }
};

module.exports = connectDB;
