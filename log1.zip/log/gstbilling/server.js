const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const connectDB = require("./db");
const User = require("./models/User");
const Business = require("./models/business");

const app = express();
const PORT = 5000;

// Connect MongoDB
connectDB();

// Middlewares
app.use(cors());
app.use(express.json());

// Test Route
app.get("/", (req, res) => {
  res.send("GST Billing Backend Running ✅");
});

// SIGNUP
app.post("/signup", async (req, res) => {
  try {
    const { password, email, ...otherData } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.json({ message: "❌ Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      ...otherData,
      email,
      password: hashedPassword,
    });

    await newUser.save();

    res.json({ message: "✅ Signup Successful" });
  } catch (error) {
    console.log("Signup Error:", error);
    res.json({ message: "❌ Something went wrong" });
  }
});

// LOGIN
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (!user) {
    return res.json({ message: "❌ Email not registered" });
  }

  const isMatch = await bcrypt.compare(password, user.password);

  if (!isMatch) {
    return res.json({ message: "❌ Incorrect password" });
  }

  res.json({ message: "✅ Login Successful" });
});

// BUSINESS ONBOARDING
app.post("/onboarding", async (req, res) => {
  try {
    const business = new Business(req.body);
    await business.save();

    res.json({ message: "Business Saved Successfully" });
  } catch (error) {
    console.log(error);
    res.json({ message: "Error saving business data" });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
