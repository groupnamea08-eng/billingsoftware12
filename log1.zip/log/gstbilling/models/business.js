const mongoose = require("mongoose");

const BusinessSchema = new mongoose.Schema({
  businessname: String,
  gstregistered: String,
  gstnumber: String,
  pannumber: String,
  businesstype: [String],     // multi-select
  state: String,
  registration: String,
  address: String,
  phoneno: String,
  email: String,
  city: String,
  pincode: String,
  details: String,
  Fassino: String,
  shopPhoto: String
});

module.exports = mongoose.model("Business", BusinessSchema);
