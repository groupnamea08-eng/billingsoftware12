function login(){
    let loginemailid = document.getElementById("loginemailid").value;
    let loginpassword = document.getElementById("loginpassword").value;
    let loginterms = document.getElementById("loginterms").checked;
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    
    if(loginemailid.trim() === ""){
       alert("Email ID is requried for login");
       return; 
    }
    if(loginpassword.trim() === ""){
       alert("Password is requried for login");
       return; 
    }

    if(!emailPattern.test(loginemailid)){
       alert("Email is Not Valid");
       return;

    }

    if(loginterms === false){
       alert("Please Accept Terms & Condition to login")
       return;   
    }

    alert("login successfully")
    console.log("Your Email " + loginemailid);
    console.log("Your Password " + loginpassword);
}

function login() {
  let loginemailid = document.getElementById("loginemailid").value;
  let loginpassword = document.getElementById("loginpassword").value;

  fetch("http://localhost:5000/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: loginemailid,
      password: loginpassword
    })
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);
  })
  .catch(error => {
    console.log("Error:", error);
  });
}
