const salesCtx = document.getElementById("salesChart").getContext("2d");

const salesChart = new Chart(salesCtx, {
    type: "line",
    data:{
      labels: ["Mon", "Tue", "Wed", "Thus", "Fri", "Sat", "Sun"],
      datasets:[
        {
            label:"Sales",
            data:[25, 30, 50, 80, 20, 0, 100],
            borderColor: "#4CAF50",
            backgroundColor: "rgba(76, 175, 80, 0.2)",
            tension: 0.4, // smooth curve
            borderWidth: 2,
        } 
      ]
    },
    options: {
     responsive : true
    }
});

const expenseCtx = document.getElementById("expenseChart").getContext("2d");

const expenseChart = new Chart(expenseCtx, {
    type: "line",
    data:{
      labels: ["Employees", "Marketing", "Transport", "Cateen", "Food", "Travel", "Holiday"],
      datasets:[
        {
            label:"Expense",
            data:[215, 140, 20, 190, 50, 20, 100],
            borderColor: "#af4c4cff",
            backgroundColor: "rgba(101, 76, 175, 0.2)",
            tension: 0.4, // smooth curve
            borderWidth: 2,
        } 
      ]
    },
    options: {
     responsive : true
    }
});

const paymentCtx = document.getElementById("paymentChart").getContext("2d");

const paymentChart = new Chart(paymentCtx, {
    type: "line",
    data:{
      labels: ["Employees", "Marketing", "Transport", "Cateen", "Food", "Travel", "Holiday"],
      datasets:[
        {
            label:"Payment",
            data:[215, 140, 20, 190, 50, 20, 100],
            borderColor: "#af4c4cff",
            backgroundColor: "rgba(101, 76, 175, 0.2)",
            tension: 0.4, // smooth curve
            borderWidth: 2,
        } 
      ]
    },
    options: {
     responsive : true
    }
});