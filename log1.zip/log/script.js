// ✅ SIGNUP VALIDATION + SEND TO BACKEND
function readsignup() {
    let contact = document.getElementById("contactperson").value;
    let businessName = document.getElementById("businessname").value;
    let phoneno = document.getElementById("phoneno").value;
    let email = document.getElementById("emailid").value;
    let password = document.getElementById("password").value;
    let cnfpassword = document.getElementById("cnfpassword").value;
    let terms = document.getElementById("terms").checked;
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    // ✅ Terms & Conditions
    if (!terms) {
        alert("Please Accept Terms & Conditions");
        return;
    }

    // ✅ Empty Fields Check
    if (
        contact.trim() === "" ||
        businessName.trim() === "" ||
        phoneno.trim() === "" ||
        email.trim() === "" ||
        password.trim() === "" ||
        cnfpassword.trim() === ""
    ) {
        alert("All fields are required");
        return;
    }

    // ✅ Email Format Check
    if (!emailPattern.test(email)) {
        alert("Invalid Email Address");
        return;
    }

    // ✅ Password Match Check
    if (password !== cnfpassword) {
        alert("Passwords do NOT match");
        return;
    }

    // ✅ Phone Number Check
    if (phoneno.length !== 10) {
        alert("Phone Number must be 10 digits");
        return;
    }

    // ✅ If all validations passed — send data to backend
    sendSignup();
}

// ✅ SEND SIGNUP DATA TO BACKEND
function sendSignup() {
    let contact = document.getElementById("contactperson").value;
    let businessName = document.getElementById("businessname").value;
    let phoneno = document.getElementById("phoneno").value;
    let email = document.getElementById("emailid").value;
    let password = document.getElementById("password").value;

    fetch("http://localhost:5000/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
           contact,
           businessName,
           phoneno,
           email,
           password
        })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error("Error:", error);
    });
}



// ✅ LOGIN VALIDATION + SEND TO BACKEND (future use)
