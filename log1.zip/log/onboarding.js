function onboarding() {

  let businessname = document.getElementById("businessname").value;
  let gst = document.querySelector("input[name='gst']:checked")?.value || "no";

  let gstnumber = document.getElementById("gstnumber").value;
  let pannumber = document.getElementById("pannumber").value;

  // MULTI SELECT for business type
  let businesstype = Array.from(
    document.getElementById("businesstype").selectedOptions
  ).map(o => o.value);

  let state = document.getElementById("state").value;
  let registration = document.getElementById("registration").value;
  let address = document.getElementById("address").value;
  let phoneno = document.getElementById("phone").value;
  let email = document.getElementById("email").value;
  let city = document.getElementById("city").value;
  let pincode = document.getElementById("pincode").value;
  let details = document.getElementById("details").value;
  let Fassino = document.getElementById("Fassino").value;

  // Validation
  if (
    businessname.trim() === "" ||
    address.trim() === "" ||
    phoneno.trim() === "" ||
    email.trim() === ""
  ) {
    alert("Please fill all required fields");
    return;
  }

  if (phoneno.length !== 10) {
    alert("Enter a valid 10-digit phone number");
    return;
  }

  // SEND TO BACKEND
  fetch("http://localhost:5000/onboarding", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      businessname,
      gstregistered: gst,
      gstnumber,
      pannumber,
      businesstype,
      state,
      registration,
      address,
      phoneno,
      email,
      city,
      pincode,
      details,
      Fassino
    })
  })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
    })
    .catch(err => console.log(err));
}


// GST show/hide
const gstRadios = document.getElementsByName("gst");
const gstFields = document.getElementById("gstFields");

gstRadios.forEach(radio => {
  radio.addEventListener("change", () => {
    gstFields.style.display = radio.value === "yes" ? "block" : "none";
  });
});

// LICENCE show/hide
const licenceRadios = document.getElementsByName("licence");
const licenceFields = document.getElementById("licencefield");

licenceRadios.forEach(radio => {
  radio.addEventListener("change", () => {
    licenceFields.style.display = radio.value === "yes" ? "block" : "none";
  });
});
